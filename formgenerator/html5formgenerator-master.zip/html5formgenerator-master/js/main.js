// JavaScript Document

	function previewMe()
	{
			alert("ss");
	}
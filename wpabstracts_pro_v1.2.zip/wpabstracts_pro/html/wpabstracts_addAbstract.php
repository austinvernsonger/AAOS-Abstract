<script>
    jQuery(document).ready(function (){
        wpabstracts_updateWordCount();
    });
</script>
<?php
    if($id && !wpabstracts_is_event_active($id)){
        wpabstracts_showMessage(__('Abstract submission for this event has past', 'wpabstracts'), 'alert-danger');
        return;
    }
    $event = (!is_admin()) ? wpabstracts_getEvents('event_id', $id, 'ARRAY_A') : 0;
?>
<div class="wpabstracts container-fluid">
    <h3><?php echo apply_filters('wpabstracts_title_filter', __('New Abstract','wpabstracts'), 'new_abstract'); ?></h3>
    <form method="post" enctype="multipart/form-data" id="abs_form">
        <div class="wpabstracts row">
            <div class="wpabstracts col-xs-12 col-sm-12 col-md-8">
                <div class="wpabstracts panel panel-default">
                    <div class="wpabstracts panel-heading">
                        <h5>
                            <?php echo apply_filters('wpabstracts_title_filter', __('Abstract Information','wpabstracts'), 'abstract_information');?>
                        </h5>
                    </div>
                    <div class="wpabstracts panel-body">
                        <div class="wpabstracts form-group">
                            <input class="wpabstracts form-control" type="text" name="abs_title" placeholder="<?php echo apply_filters('wpabstracts_title_filter', __('Enter Title','wpabstracts'), 'enter_title');?>" value="" id="title" />
                        </div>
                        <div class="wpabstracts form-group">
                            <?php $settings = array( 'media_buttons' => false, 'wpautop'=>true, 'dfw' => true, 'editor_height' => 360, 'quicktags' => false); ?>
                            <?php wp_editor(stripslashes(get_option('wpabstracts_author_instructions')), 'abstext', $settings); ?>
                            <span class="wpabstracts max-word-count" style="display: none;"><?php echo get_option('wpabstracts_chars_count'); ?></span>
                            <table id="post-status-info" cellspacing="0">
                                <tbody><tr><td id="wp-word-count"><?php printf( __( 'Word count: %s' ), '<span class="wpabstracts abs-word-count">0</span>' ); ?></td></tr></tbody>
                            </table>
                        </div>
                        <?php if(get_option('wpabstracts_show_keywords')){ ?>
                        <div class="wpabstracts form-group">
                            <input class="wpabstracts form-control" type="text" name="abs_keywords" id="abs_keywords" placeholder="<?php echo apply_filters('wpabstracts_title_filter', __('Enter comma separated keywords','wpabstracts'), 'enter_keywords');?>" value="" />
                        </div>
                        <?php } ?>
                    </div>
                 </div>
                <?php if(get_option('wpabstracts_show_attachments')){ ?>
                    <div class="wpabstracts panel panel-default">

                        <div class="wpabstracts panel-heading">
                           <h5><?php echo apply_filters('wpabstracts_title_filter', __('Attachments','wpabstracts'), 'attachments');?></h5>
                        </div>

                        <div class="wpabstracts panel-body">

                            <dl class="wpabstracts form-group">
                                <dd><?php _e('Use this form to upload your images, photos or tables.', 'wpabstracts'); ?></dd>
                                <dd><?php _e('Supported formats', 'wpabstracts'); ?>: <strong><?php echo implode(' ', explode(' ', get_option('wpabstracts_permitted_attachments'))); ?></strong></dd>
                                <dd><?php _e('Maximum attachment size', 'wpabstracts'); ?>: <strong><?php echo number_format((get_option('wpabstracts_max_attach_size') / 1048576)); ?>MB</strong></dd>
                            </dl>
                            <dl class="wpabstracts form-group">
                                <?php
                                    for($i = 0; $i < get_option('wpabstracts_upload_limit'); $i++){ ?>
                                        <dd>
                                            <input type="file" name="attachments[]">
                                        </dd>
                                <?php } ?>
                            </dl>
                        </div>
                    </div>
                <?php } ?>

                <?php if(get_option('wpabstracts_show_conditions')){ ?>
                <div class="wpabstracts panel panel-default">

                    <div class="wpabstracts panel-heading">
                        <h5>
                            <?php echo apply_filters('wpabstracts_title_filter', __('Terms and Conditions','wpabstracts'), 'terms_conditions');?>
                            <input type="checkbox" name="abs_terms"  id="abs_terms"/>
                        </h5>
                    </div>

                    <div class="wpabstracts panel-body">
                        <div class="wpabstracts terms_conditons">
                            <?php echo stripslashes(get_option('wpabstracts_terms_conditions'));?>
                        </div>
                    </div>
                </div>
            <?php } ?>
                <button type="button" onclick="wpabstracts_validateAbstract();" class="wpabstracts btn btn-primary"><?php _e('Submit','wpabstracts');?></button>
            </div>
            <div class="wpabstracts col-xs-12 col-md-4">
                <div class="wpabstracts panel panel-default">

                    <div class="wpabstracts panel-heading">
                        <h5><?php echo apply_filters('wpabstracts_title_filter', __('Event Information','wpabstracts'), 'event_information');?></h5>
                    </div>

                    <div class="wpabstracts panel-body">

                        <div class="wpabstracts form-group">
                            <label class="wpabstracts control-label" for="abs_event"><?php echo apply_filters('wpabstracts_title_filter', __('Event','wpabstracts'), 'event');?></label>
                            <?php if(is_admin()){ ?>
                            <select name="abs_event" id="abs_event" class="wpabstracts form-control" onchange="wpabstracts_getTopics(this.value);">
                                    <option value="" style="display:none;"><?php echo apply_filters('wpabstracts_title_filter', __('Select an Event','wpabstracts'), 'select_event');?></option>
                                    <?php foreach($events as $event){ ?>
                                        <option value="<?php echo esc_attr($event->event_id);?>"><?php echo esc_attr($event->name);?></option>
                                    <?php } ?>
                            </select>
                            <div class="wpabstracts form-group">
                                <label class="wpabstracts control-label" for="abs_topic"><?php echo apply_filters('wpabstracts_title_filter', __('Topic','wpabstracts'), 'topic');?></label>
                                <select name="abs_topic" id="abs_topic" class="wpabstracts form-control">
                                    <option value="" style="display:none;"><?php echo apply_filters('wpabstracts_title_filter', __('Select a Topic','wpabstracts'), 'select_topic');?></option>
                                </select>
                            </div>
                            <?php } else { ?>
                                <div class="wpabstracts form-group">
                                    <?php echo esc_attr($event['name']);?>
                                    <input type="hidden" name="abs_event" value="<?php echo esc_attr($event['event_id']);?>">
                                </div>
                                <div class="wpabstracts form-group">
                                    <label class="wpabstracts control-label" for="abs_topic"><?php echo apply_filters('wpabstracts_title_filter', __('Topic','wpabstracts'), 'topic');?></label>
                                    <select name="abs_topic" id="abs_topic" class="wpabstracts form-control">
                                        <option value="" style="display:none;"><?php echo apply_filters('wpabstracts_title_filter', __('Select a Topic','wpabstracts'), 'select_topic');?></option>
                                        <?php $topics = explode(',', $event['topics']); ?>
                                        <?php foreach($topics as $topic){ ?>
                                        <option value="<?php echo esc_attr($topic);?>"><?php echo esc_attr($topic);?></option>
                                    <?php } ?>
                                    </select>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
                <?php if(get_option('wpabstracts_show_author')){?>
                    <div class="wpabstracts panel panel-default">

                        <div class="wpabstracts panel-heading">
                            <h5>
                                <?php echo apply_filters('wpabstracts_title_filter', __('Author Information','wpabstracts'), 'author_information');?>
                                <span class="wpabstracts glyphicon glyphicon-minus-sign delete_author" onclick="wpabstracts_delete_coauthor();"></span>
                                <span class="wpabstracts glyphicon glyphicon-plus-sign add_author" onclick="wpabstracts_add_coauthor();"></span>
                            </h5>
                        </div>

                        <div class="wpabstracts panel-body" id="coauthors_table">

                            <div class="wpabstracts form-group author_box">
                                <label class="wpabstracts control-label" for="abs_author[]"><?php _e('Name','wpabstracts');?></label>
                                <input class="wpabstracts form-control" type="text" name="abs_author[]" id="abs_author[]"  />

                                <label class="wpabstracts control-label" for="abs_author_email[]"><?php _e('Email','wpabstracts');?></label>
                                <input class="wpabstracts form-control" type="text" name="abs_author_email[]" id="abs_author_email[]" />

                                <label class="wpabstracts control-label" for="abs_author_affiliation[]"><?php _e('Affiliation','wpabstracts');?></label>
                                <input class="wpabstracts form-control" type="text" name="abs_author_affiliation[]" id="abs_author_affiliation[]"/>

                            </div>
                        </div>

                    </div>
                <?php } ?>

                <?php if(get_option('wpabstracts_show_presenter')){ ?>
                <div class="wpabstracts panel panel-default">

                    <div class="wpabstracts panel-heading">
                        <h5><?php echo apply_filters('wpabstracts_title_filter', __('Presenter Information','wpabstracts'), 'presenter_information');?></h5>
                    </div>

                    <div class="wpabstracts panel-body">

                        <div class="wpabstracts form-group">
                            <label class="wpabstracts control-label" for="abs_presenter"><?php _e('Name','wpabstracts');?></label>
                            <input class="wpabstracts form-control" type="text" name="abs_presenter" id="abs_presenter"/>
                        </div>

                        <div class="wpabstracts form-group">
                            <label class="wpabstracts control-label" for="abs_presenter_email"><?php _e('Email','wpabstracts');?></label>
                            <input class="wpabstracts form-control" type="text" name="abs_presenter_email" id="abs_presenter_email"/>
                        </div>

                        <div class="wpabstracts form-group">
                            <label class="wpabstracts control-label" for="abs_presenter_preference"><?php echo apply_filters('wpabstracts_title_filter', __('Presenter Preference','wpabstracts'), 'presenter_preference');?></label>
                            <select class="wpabstracts form-control" name="abs_presenter_preference" id="abs_presenter_preference">
                                <option value="" style="display:none;"><?php _e('Preference','wpabstracts');?></option>
                                <?php
                                    $presenter_preference = explode(',', get_option('wpabstracts_presenter_preference'));
                                    foreach($presenter_preference as $preference){ ?>
                                        <option value="<?php echo $preference; ?>"><?php echo $preference; ?></option>
                                <?php } ?>
                            </select>
                        </div>

                    </div>
                </div>
            <?php } ?>
            </div>
        </div>
    </form>
</div>


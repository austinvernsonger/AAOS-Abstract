<?php
/**
 * New User HTML Template
 * Kevon Adonis
 * Copyright 2015
 * http://www.wpabstracts.com
 */
?>
<div class="wpabstracts container-fluid">

    <div class="wpabstracts alert alert-warning" role="alert">
        <h5><span class="glyphicon glyphicon-info-sign"></span> We could not find a profile for you. Please take a few minutes to create one now.</h5>
    </div>
    <h4><span class="wpabstracts glyphicon glyphicon-plus"></span> Create Profile</h4>
    <form method="post" enctype="multipart/form-data" id="wpa_account_form">
        <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">General Information</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="first_name">First Name</label>
                    <input type="text" name="first_name" class="wpabstracts form-control" id="first_name">
                </div>
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="last_name">Surname</label>
                    <input type="text" name="last_name" class="wpabstracts form-control" id="last_name">
                </div>
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="reg_type">Registration Type</label>
                    <select name="reg_type" class="wpabstracts form-control" id="reg_type">
                          <option value="">Select an option</option>
                          <option value="Professional">Professional</option>
                          <option value="Professional 2 Days">Professional 2 Days</option>
                          <option value="Student">Student</option>
                          <option value="Retired">Retired</option>
                          <option value="Accompanying Person">Accompanying Person</option>
                      </select>
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="title">Title</label>
                    <select name="title" class="wpabstracts form-control" id="title">
                        <option value="">Select an option</option>
                        <option value="Prof">Prof</option>
                        <option value="Dr">Dr</option>
                        <option value="Mr">Mr</option>
                        <option value="Mrs">Mrs</option>
                    </select>
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="gender">Gender</label>
                    <select name="gender" class="wpabstracts form-control" id="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </div>
                <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="telephone">Phone number</label>
                    <input type="text" name="telephone" class="wpabstracts form-control" id="telephone" placeholder="Ex. 0039123456789">
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="alt_email">Alternative email</label>
                    <input type="text" name="alt_email" class="wpabstracts form-control" id="alt_email">
                </div>
            </div>
            </div>
        </div>
        <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">Organization</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-6">
                    <label class="wpabstracts control-label" for="organization">Institution / Company</label>
                    <input type="text" name="organization" class="wpabstracts form-control" id="organization">
                </div>
                <div class="wpabstracts form-group col-xs-6 required">
                    <label class="wpabstracts control-label" for="country">Country</label>
                    <input type="text" name="country" class="wpabstracts form-control" id="country">
                </div>
            </div>
        </div>

        <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">Conference Information</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-3 required">
                    <label class="wpabstracts control-label" for="oral_presenter">Are you an oral presenter?</label>
                    <select name="oral_presenter" class="wpabstracts form-control" id="oral_presenter">
                          <option value="">Select an option</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                          <option value="Maybe">Maybe</option>
                      </select>
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="oral_code">If YES, what is the abstract code?</label>
                    <input type="text" name="oral_code" class="wpabstracts form-control" id="oral_code" placeholder="Ex.: HE01_234">
                </div>
                <div class="wpabstracts form-group col-xs-3 required">
                    <label class="wpabstracts control-label" for="poster_presenter">Are you an Poster presenter?</label>
                    <select name="poster_presenter" class="wpabstracts form-control" id="poster_presenter">
                          <option value="">Select an option</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                          <option value="Maybe">Maybe</option>
                      </select>
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="poster_code">If YES, what is the abstract code?</label>
                    <input type="text" name="poster_code" class="wpabstracts form-control" id="poster_code" placeholder="Ex.: HE01_234">
                </div>
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="badge_name">Name on your badge</label>
                    <input type="text" name="badge_name" class="wpabstracts form-control" id="badge_name">
                </div>
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="badge_org">Organization on your badge</label>
                    <input type="text" name="badge_org" class="wpabstracts form-control" id="badge_org">
                </div>
                <div class="wpabstracts form-group col-xs-4 required">
                    <label class="wpabstracts control-label" for="printed_abstracts">Printed copy of book of abstracts</label>
                    <select name="printed_abstracts" class="wpabstracts form-control" id="printed_abstracts">
                        <option value="">Select an option</option>
                          <option value="Yes">Yes</option>
                          <option value="No">No</option>
                      </select>
                </div>
            </div>
        </div>

        <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">Other Information</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="hotel_internal">My hotel in Nova Yardinia</label>
                    <select name="hotel_internal" class="wpabstracts form-control" id="hotel_internal">
                          <option value="">Select an option</option>
                          <option value="Kalidria Hotel">Kalidria Hotel</option>
                          <option value="Alborea Hotel">Alborea Hotel</option>
                          <option value="Calene Hotel">Calene Hotel</option>
                          <option value="Valentino Hotel">Valentino Hotel</option>
                      </select>
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="hotel_external">My Hotel outside Nova Yardinia</label>
                    <input type="text" name="hotel_external" class="wpabstracts form-control" id="hotel_external">
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="flight_arrival">My flight arrives Sunday at [hh:mm]</label>
                    <input type="text" name="flight_arrival" class="wpabstracts form-control" id="flight_arrival">
                </div>
                <div class="wpabstracts form-group col-xs-3">
                    <label class="wpabstracts control-label" for="flight_departure">My flight leaves Saturday at [hh:mm]</label>
                    <input type="text" name="flight_departure" class="wpabstracts form-control" id="flight_departure">
                </div>
                <div class="wpabstracts form-group col-xs-12">
                    <label class="wpabstracts control-label" for="dietary_restrictions">Dietary Restrictions</label>
                    <textarea name="dietary_restrictions" class="wpabstracts form-control" id="dietary_restrictions"></textarea>
                </div>
            </div>

        </div>

<!--        <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">Contacts</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group col-xs-6">
                    <label class="wpabstracts control-label" for="telephone">Phone number</label>
                    <input type="text" name="telephone" class="wpabstracts form-control" id="telephone" placeholder="Ex. 0039123456789">
                </div>
                <div class="wpabstracts form-group col-xs-6">
                    <label class="wpabstracts control-label" for="alt_email">Alternative email</label>
                    <input type="text" name="alt_email" class="wpabstracts form-control" id="alt_email">
                </div>
            </div>
        </div>-->
         <div class="wpabstracts panel panel-default">
            <div class="wpabstracts panel-heading">
              <h3 class="wpabstracts panel-title">Terms of Participation</h3>
            </div>
            <div class="wpabstracts panel panel-body">
                <div class="wpabstracts form-group required">
                    <span class="wpabstracts help-block">
                        Conferences organized by the Associazione Italiana per lo Studio delle Argille (AISA), a no-profit scientific society, can be attended by its members only. Therefore, to participate in the DUST 2016, you must be a member of AISA and the payment of the conference fee is intended as a declaration that you are asking to be member of AISA. On the basis of the Italian laws, we have to register you in our Book of Members for the 2016. This doesn’t imply any commitment from your part and all the information stored in our systems will be deleted after the conference.
                    </span>
                    <label class="wpabstracts control-label" for="terms_conditions">I agree</label>
                    <input type="checkbox" name="terms_conditions" id="terms_conditions">
                </div>
            </div>
        </div>


        <button type="button" onclick="wpabstracts_validateUser();" class="btn btn-primary btn-lg">Save Profile</button>

    </form>
</div>

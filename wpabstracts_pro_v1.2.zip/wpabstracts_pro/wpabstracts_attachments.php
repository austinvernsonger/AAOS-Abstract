<?php
defined('ABSPATH') or die("ERROR: You do not have permission to access this page");

if(!class_exists('WPAbstract_Attachments_Table')){
    require_once( WPABSTRACTS_PLUGIN_DIR . 'inc/wpabstracts_classes.php' );
}
if(is_admin() && isset($_GET['tab']) && $_GET["tab"] == "attachments"){
    if(isset($_GET["task"]) && $_GET["task"]){

        $task = sanitize_text_field($_GET["task"]);

        switch($task){
            case 'delete':
                if(current_user_can(WPABSTRACTS_ACCESS_LEVEL)){
                    wpabstracts_deleteAttachment(intval($_GET['id']), true );
                }
            default :
                wpabstracts_showAttachments();
        }
    }else{
        wpabstracts_showAttachments();
    }
}

function wpabstracts_deleteAttachment($id, $message){
    global $wpdb;
    $wpdb->query("DELETE FROM " . $wpdb->prefix."wpabstracts_attachments WHERE attachment_id = " . $id);
    if($message){
        wpabstracts_showMessage("Attachment ID ". $id . " was successfully deleted", 'alert-success');
    }
}

function wpabstracts_showAttachments(){ ?>
    <div class="wpabstracts container-fluid wpabstracts-admin-container">
        <h3><?php echo apply_filters('wpabstracts_title_filter', __('Attachments','wpabstracts'), 'abstracts');?>  <a href="?page=wpabstracts&tab=attachments&task=download&type=zip" role="button" class="wpabstracts btn btn-primary"><?php _e('Export Attachments', 'wpabstracts');?></a></h3>
    </div>
    <form id="showAttachments" method="get">
    <input type="hidden" name="page" value="wpabstracts" />
    <input type="hidden" name="tab" value="attachments" />
       <?php
            $showAttachments = new WPAbstract_Attachments_Table();
            $showAttachments->prepare_items();
            $showAttachments->display();
        ?>
</form>
    <?php
}
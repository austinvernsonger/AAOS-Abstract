<?php
defined('ABSPATH') or die("ERROR: You do not have permission to access this page");

if(!class_exists('WPAbstracts_EmailsTemplates')){
    require_once( WPABSTRACTS_PLUGIN_DIR . 'inc/wpabstracts_classes.php' );
}

if(is_admin() && isset($_GET['tab']) && ($_GET["tab"]=="emails")){
    if(isset($_GET['task'])){
        $task = sanitize_text_field($_GET['task']);
        $id = intval($_GET['id']);
        switch($task){
            case 'edit':
                wpabstracts_editEmail($id);
                break;
            default :
                wpabstracts_showEmails();
                break;
        }
    }else{
        wpabstracts_showEmails();
    }
}

function wpabstracts_editEmail($id) {
    global $wpdb;

    if($_POST){
        $template_name = sanitize_text_field($_POST["template_name"]);
        $from_name = sanitize_text_field($_POST["from_name"]);
        $from_email = sanitize_text_field($_POST["from_email"]);
        $email_subject = sanitize_text_field($_POST["email_subject"]);
        $email_body = wp_kses_post($_POST["email_body"]);
        $wpdb->show_errors();
        $data = array(
            'name' => $template_name, 'subject' => $email_subject, 'message' => $email_body,
            'from_name' => $from_name, 'from_email' => $from_email);
        $where = array( 'ID' => $id);
        $wpdb->update($wpdb->prefix."wpabstracts_emailtemplates", $data, $where);

        wpabstracts_redirect('?page=wpabstracts&tab=emails');

    }else{
        wpabstracts_getEditView('EmailTemplate', $id, 'backend');
    }
}


function wpabstracts_showEmails(){ ?>
        <form id="showReviews" method="get">
            <input type="hidden" name="page" value="wpabstracts" />
            <input type="hidden" name="tab" value="emails" />
            <?php
            $showEmails = new WPAbstracts_EmailsTemplates();
            $showEmails->prepare_items();
            $showEmails->display(); ?>
            </form>
    <?php
}


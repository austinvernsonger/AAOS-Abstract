<?php
defined('ABSPATH') or die("ERROR: You do not have permission to access this page");
if(!class_exists('WPAbstract_Abstracts_Table')){
    require_once( WPABSTRACTS_PLUGIN_DIR . 'inc/wpabstracts_classes.php' );
}
    if($_GET["tab"]=="events") {
        if(isset($_GET["task"])){
            $task = $_GET["task"];
            switch($task){
                case 'new':
                    wpabstracts_addEvent();
                    break;
                case 'edit':
                    wpabstracts_editEvent($_GET["id"]);
                    break;
                case 'delete':
                    wpabstracts_deleteEvent($_GET['id']);
                default :
                    wpabstracts_showEvents();
                    break;
            }
        }else{
            wpabstracts_showEvents();
        }
    }
    else{
        echo "You do not have permission to view this page";
    }

function wpabstracts_addEvent() {
    global $wpdb;
    $tab = "?page=wpabstracts&tab=events";
        if ($_POST) {
            $abs_event_name = sanitize_text_field($_POST["abs_event_name"]);
            $abs_event_desc = wp_kses_post($_POST["abs_event_desc"]);
            $abs_event_address = sanitize_text_field($_POST["abs_event_address"]);
            $abs_event_host = sanitize_text_field($_POST["abs_event_host"]);
            $abs_event_start = sanitize_text_field($_POST["abs_event_start"]);
            $abs_event_end = sanitize_text_field($_POST["abs_event_end"]);
            $abs_event_deadline = sanitize_text_field($_POST["abs_event_deadline"]);
            // get and sanitize topics
            if(sizeof($_POST["topics"])>1) {
                foreach($_POST["topics"] as $key=>$topic) {
                    $topic = sanitize_text_field($_POST["topics"][$key]);
                    $topics[] = $topic;
                }
            $event_topics = implode(', ',$topics);
            } else {
                $topic = sanitize_text_field($_POST["topics"][0]);
                $event_topics = $topic;
            }
            $wpdb->show_errors();
            $wpdb->query($wpdb->prepare("INSERT INTO ".$wpdb->prefix."wpabstracts_events (name, description, address, host, topics, start_date, end_date, deadline)
                                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s)",$abs_event_name,$abs_event_desc,$abs_event_address,$abs_event_host,$event_topics,$abs_event_start,$abs_event_end,$abs_event_deadline));

            wpabstracts_redirect($tab);
        }
        else {
            wpabstracts_getAddView('Event', null, 'backend');
        }
}

function wpabstracts_editEvent($id){
    global $wpdb;
    $tab = "?page=wpabstracts&tab=events";
        if ($_POST) {
            $abs_event_name = sanitize_text_field($_POST["abs_event_name"]);
            $abs_event_desc = wp_kses_post($_POST["abs_event_desc"]);
            $abs_event_address = sanitize_text_field($_POST["abs_event_address"]);
            $abs_event_host = sanitize_text_field($_POST["abs_event_host"]);
            $abs_event_start = sanitize_text_field($_POST["abs_event_start"]);
            $abs_event_end = sanitize_text_field($_POST["abs_event_end"]);
            $abs_event_deadline = sanitize_text_field($_POST["abs_event_deadline"]);
            // get and sanitize topics
            if(sizeof($_POST["topics"])>1) {
                foreach($_POST["topics"] as $key=>$topic) {
                    $topic = sanitize_text_field($_POST["topics"][$key]);
                    $topics[] = $topic;
                }
            $event_topics = implode(', ',$topics);
            } else {
                $topic = sanitize_text_field($_POST["topics"][0]);
                $event_topics = $topic;
            }
            $wpdb->show_errors();
            $wpdb->query("UPDATE ".$wpdb->prefix."wpabstracts_events
                        SET name = '$abs_event_name', description = '$abs_event_desc', address = '$abs_event_address', "
                    . "host = '$abs_event_host', topics = '$event_topics', start_date = '$abs_event_start', "
                    . "end_date = '$abs_event_end', deadline = '$abs_event_deadline' "
                    . "WHERE event_id = $id");

            wpabstracts_redirect($tab);
        }
        else {
            wpabstracts_getEditView('Event', $id, 'backend');
        }
}

function wpabstracts_showEvents(){ ?>
<div class="wpabstracts container-fluid wpabstracts-admin-container">
    <h3><?php echo apply_filters('wpabstracts_title_filter', __('Events','wpabstracts'), 'events');?> <a href="?page=wpabstracts&tab=events&task=new" class="wpabstracts btn btn-primary" /><?php _e('Add New', 'wpabstracts');?></a></h3>
</div>
    <form id="showsEvents" method="get">
        <input type="hidden" name="page" value="wpabstracts" />
        <input type="hidden" name="tab" value="events" />
           <?php
                $showEvents = new WPAbstract_Events_Table();
                $showEvents ->prepare_items();
                $showEvents ->display();
            ?>
    </form>


   <?php
}

function wpabstracts_deleteEvent($id){
    global $wpdb;
        $wpdb->show_errors();
        $wpdb->query("delete from ".$wpdb->prefix."wpabstracts_events where event_id=".$id);
        ?>
    <div id="message" class="updated fade"><p><strong><?php _e('Event deleted', 'wpabstracts');?>.</strong></p></div>
        <?php
}

function wpabstracts_loadTopics(){
    global $wpdb;
    if($_POST[event_id]){
        $event_id = intval($_POST[event_id]);
        $event = $wpdb->get_row("SELECT topics FROM ".$wpdb->prefix."wpabstracts_events Where event_id = $event_id");
        $topics = explode(',',$event->topics);
        foreach($topics as $topic){ ?>
            <option value="<?php echo esc_attr($topic);?>"><?php echo esc_attr($topic);?></option>;
        <?php }
    }else{
   _e("Error!", 'wpabstracts');
    }
   die();
}
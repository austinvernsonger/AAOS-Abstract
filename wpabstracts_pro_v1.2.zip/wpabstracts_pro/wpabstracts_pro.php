<?php
/*
Plugin Name: WP Abstracts Pro
Plugin URI: http://www.wpabstracts.com
Description: Use WP Abstracts Pro to allow and manage Abstracts and Manuscripts submissions on your site. </br>Manage authors, reviews, events and more
Version: 1.2
Author: Kevon Adonis
Author URI: http://www.kevonadonis.com
*/
defined('ABSPATH') or die("ERROR: You do not have permission to access this page");
define('WPABSTRACTS_ACCESS_LEVEL', 'manage_options');
define('WPABSTRACTS_PLUGIN_DIR', dirname(__FILE__).'/' );
define('WPABSTRACTS_VERSION', '1.2');

add_action('init', 'wpabstracts_init');
add_action('admin_menu', 'wpabstracts_register_menu');
add_action('admin_init', 'wpabstracts_disable_dashboard');
add_action('wp_ajax_getreviewers', 'wpabstracts_getreviewers_ajax');
add_action('wp_ajax_managereviews', 'wpabstracts_checkreviews_ajax');
add_action('wp_ajax_loadtopics', 'wpabstracts_loadtopics_ajax');
add_filter('show_admin_bar', 'wpabstracts_disable_adminbar');
add_filter('plugin_row_meta', 'wpabstracts_plugin_links', 10, 2);
add_filter('tiny_mce_before_init', 'wpabstracts_editor_init' );
add_filter('pre_set_site_transient_update_plugins', 'wpabstracts_updater');
add_filter('plugins_api', 'wpabstracts_api_call', 10, 3);
add_action('plugins_loaded', 'wpabstracts_version_check');
add_shortcode('wpabstracts', 'wpabstracts_dashboard_shortcode');
add_shortcode('wpabstracts_author', 'wpabstracts_author_shortcode');
add_shortcode('wpabstracts_reviewer', 'wpabstracts_reviewer_shortcode');
register_activation_hook(__FILE__, 'wpabstracts_install');

global $pagenow;
if ('admin.php' == $pagenow && isset($_GET['page']) && ($_GET['page'] == 'wpabstracts')){
    add_action('admin_head', 'wpabstracts_loadJS');
    add_action('admin_init', 'wpabstracts_loadCSS');
    add_action('admin_init', 'wpabstracts_editor_admin_init');
}

if(isset($_REQUEST['action']) && $_REQUEST['action']=='loadtopics'):
        do_action( 'wp_ajax_' . $_REQUEST['action'] );
endif;

function wpabstracts_init() {
    load_plugin_textdomain('wpabstracts', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    include( WPABSTRACTS_PLUGIN_DIR . 'inc/wpabstracts_functions.php' );
    include( apply_filters('wpabstracts_page_include', WPABSTRACTS_PLUGIN_DIR . 'inc/wpabstracts_downloads.php') );
}

function wpabstracts_register_menu(){
    $page_title = __('WP Abstracts Pro', 'wpabstracts');
    add_menu_page( $page_title, $page_title, 'manage_options', 'wpabstracts', 'wpabstracts_admin_dashboard', plugins_url( 'images/icon.png', __FILE__), 99 );
    $submenus = array(
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Summary','wpabstracts'), 'summary'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=summary'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Abstracts','wpabstracts'), 'abstracts'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=abstracts'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Events','wpabstracts'), 'events'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=events'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Reviews','wpabstracts'), 'reviews'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=reviews'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Attachments','wpabstracts'), 'attachments'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=attachments'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Users','wpabstracts'), 'users'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=users'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Reports','wpabstracts'), 'reports'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=reports'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Settings','wpabstracts'), 'settings'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=settings'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Emails','wpabstracts'), 'emails'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=emails'),
        array('page_title' => $page_title, 'menu_name' => apply_filters('wpabstracts_title_filter', __('Help','wpabstracts'), 'help'), 'capability' => 'manage_options', 'url' => 'admin.php?page=wpabstracts&tab=help'),
    );

    $filter_menus = apply_filters('wpabstracts_menu_filter', $submenus);

    foreach($filter_menus as $submenu){
        add_submenu_page( 'wpabstracts',  $submenu['page_title'], $submenu['menu_name'], $submenu['capability'], $submenu['url'] );
    }
    remove_submenu_page('wpabstracts','wpabstracts');
}

function wpabstracts_dashboard_shortcode($atts) {
    global $wpdb;
    wpabstracts_loadCSS(); //load css only on dashboard pages
    wpabstracts_loadJS();  //load js only on dashboard pages
    $args = array('event_id' => 0); // shortcode args with defaults
    $a = shortcode_atts( $args, $atts);
    $event_id = intval($a['event_id']);
    $event = $wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix."wpabstracts_events WHERE event_id = ".$event_id);
    if(!$event_id || !$event){
        $errorMsg = __('Please enter a valid event ID', 'wpabstracts') . '<br>' .
                    __('The shortcode in this page should be similar to [wpabstracts event_id=EventID]', 'wpabstracts');
        wpabstracts_showMessage($errorMsg, 'alert-danger');
        return;
    }
    ob_start();
    $dashboard = apply_filters('wpabstracts_page_include', 'html/wpabstracts_dashboard.php');
    include($dashboard);
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}

function wpabstracts_author_shortcode($atts) {
    global $wpdb;
    wpabstracts_loadCSS(); //load css only on dashboard pages
    wpabstracts_loadJS();  //load js only on dashboard pages
    $args = array('event_id' => 0); // shortcode args with defaults
    $a = shortcode_atts( $args, $atts);
    $event_id = intval($a['event_id']);
    $event = $wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix."wpabstracts_events WHERE event_id = ". $event_id);
    if(!$event_id || !$event){
        $errorMsg = __('Please enter a valid event ID', 'wpabstracts') . '<br>' .
                    __('The shortcode in this page should be similar to [wpabstracts event_id=EventID]', 'wpabstracts');
        wpabstracts_showMessage($errorMsg, 'alert-danger');
        return;
    }
    ob_start();
    $dashboard = apply_filters('wpabstracts_page_include', 'html/wpabstracts_dashboard.php');
    include($dashboard);
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}

function wpabstracts_reviewer_shortcode($atts) {
    global $wpdb;
    wpabstracts_loadCSS(); //load css only on dashboard pages
    wpabstracts_loadJS();  //load js only on dashboard pages
    $args = array('event_id' => 0); // shortcode args with defaults
    $a = shortcode_atts( $args, $atts);
    $event_id = intval($a['event_id']);
    $event = $wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix."wpabstracts_events WHERE event_id = ".$event_id);
    if(!$event_id || !$event){
        $errorMsg = __('Please enter a valid event ID', 'wpabstracts') . '<br>' .
                    __('The shortcode in this page should be similar to [wpabstracts event_id=EventID]', 'wpabstracts');
        wpabstracts_showMessage($errorMsg, 'alert-danger');
        return;
    }
    ob_start();
    $dashboard = apply_filters('wpabstracts_page_include', 'html/wpabstracts_dashboard.php');
    include($dashboard);
    $html = ob_get_contents();
    ob_end_clean();
    return $html;
}

function wpabstracts_disable_dashboard() {
    if(!get_option('wpabstracts_frontend_dashboard')) {
       if (is_admin() && !current_user_can( 'administrator' ) && !( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
            wp_redirect( home_url() );
            exit;
        }
    }
}

function wpabstracts_disable_adminbar() {
    if(is_user_logged_in() && get_option('wpabstracts_show_adminbar')){
	return true;
    }
    return false;
}

function wpabstracts_plugin_links($links, $file) {

    if ($file == plugin_basename(__FILE__)) {
        $links[] = '<a href="http://www.wpabstracts.com/contact/requests/" target="_blank">' . __('Request Customization', 'wpabstracts') . '</a>';
        $links[] = '<a href="http://www.wpabstracts.com/support" target="_blank">' . __('Support', 'wpabstracts') . '</a>';
    }
    return $links;
}

function wpabstracts_admin_header(){
    $header = '<div class="wpabstracts container-fluid">' .
        '<div class="wpabstracts row">' .
            '<div class="wpabstracts logo col-xs-12">' .
            '<a href="?page=wpabstracts"><img src="'. plugins_url("images/admin_logo.png", __FILE__) . '"></a>' .
            '<span style="vertical-align: middle; font-size: 11px; color: #44648A;">Pro v' . WPABSTRACTS_VERSION . '</span>' .
        '</div></div></div>';
    echo apply_filters('wpabstracts_admin_header', $header);
}

function wpabstracts_admin_dashboard() {
    global $pagenow;

    if ( $pagenow == 'admin.php' && $_GET['page'] == 'wpabstracts' ){

        $tab = isset($_GET['tab']) ? $_GET['tab']  : 'summary';

        wpabstracts_admin_header();
        wpabstracts_admin_tabs($tab);

        switch ($tab){
            case 'summary' :
                $page = 'wpabstracts_summary.php';
                break;
            case 'abstracts' :
                $page = 'wpabstracts_abstracts.php';
                break;
            case 'events' :
                $page =  'wpabstracts_events.php';
                break;
            case 'reviews' :
                $page = 'wpabstracts_reviews.php';
                break;
            case 'attachments' :
                $page = 'wpabstracts_attachments.php';
                break;
            case 'users' :
                $page = 'wpabstracts_users.php';
                break;
             case 'reports' :
                $page = 'wpabstracts_reports.php';
                break;
	    case 'settings' :
                $page = 'wpabstracts_settings.php';
                break;
            case 'emails' :
                $page = 'wpabstracts_emails.php';
                break;
            case 'help' :
                $page = 'wpabstracts_help.php';
                break;
            default:
                $page = 'wpabstracts_summary.php';
	}

        $page = apply_filters('wpabstracts_page_include', $page);
        ob_start();
        include $page;
        $html = ob_get_contents();
        ob_end_clean();
        echo apply_filters('wpabstracts_admin_pages', $html, $tab);

    }

}

function wpabstracts_admin_tabs( $current = 'summary' ) {
    $basic_tabs = array(
        'summary' => apply_filters('wpabstracts_title_filter', __('Summary','wpabstracts'), 'summary'),
        'abstracts' => apply_filters('wpabstracts_title_filter', __('Abstracts','wpabstracts'), 'abstracts'),
        'events' => apply_filters('wpabstracts_title_filter', __('Events','wpabstracts'), 'events'),
        'reviews' => apply_filters('wpabstracts_title_filter', __('Reviews','wpabstracts'), 'reviews'),
        'attachments' => apply_filters('wpabstracts_title_filter', __('Attachments','wpabstracts'), 'attachments'),
        'users' => apply_filters('wpabstracts_title_filter', __('Users','wpabstracts'), 'users'),
        'reports' => apply_filters('wpabstracts_title_filter', __('Reports','wpabstracts'), 'reports'),
        'emails' => apply_filters('wpabstracts_title_filter', __('Emails','wpabstracts'), 'emails')
    );

    $tabs = apply_filters('wpabstracts_admin_tabs', $basic_tabs);
    $tabs['settings'] = apply_filters('wpabstracts_title_filter', __('Settings','wpabstracts'), 'settings');
    $tabs['help'] = apply_filters('wpabstracts_title_filter', __('Help','wpabstracts'), 'help');

    $top_menu = '<div class="wpabstracts container-fluid">';
    $top_menu .= '<ul class="wpabstracts nav nav-tabs">';
    foreach( $tabs as $tab => $name ){
        $class = ( $tab == $current ) ? "wpabstracts active" : "";
        $top_menu .= "<li role='presentation' class='".$class."'><a href='?page=wpabstracts&tab=$tab'><strong>$name</strong></a></li>";
    }
    $top_menu .= '</ul>';
    $top_menu .= '</div>';
    echo $top_menu;
}

function wpabstracts_install() {
   global $wpdb;
   require_once(ABSPATH.'wp-admin/includes/upgrade.php');
   // reviews table
   $table_name = $wpdb->prefix."wpabstracts_reviews";
   $sql = "CREATE TABLE ".$table_name." (
		  review_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		  abstract_id int(11),
		  user_id int(11),
		  status varchar(25),
		  relevance varchar(25),
		  quality varchar(25),
		  comments text,
                  recommendation varchar(25),
                  customized int(11),
                  review_date datetime,
		  PRIMARY KEY (review_id)

	  );";

      dbDelta($sql);
    $table_name = $wpdb->prefix."wpabstracts_abstracts";
    $sql = "CREATE TABLE ".$table_name." (
		  abstract_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		  title text,
		  text longtext,
		  event int(11),
                  topic text,
                  status varchar(25),
		  author text,
		  author_email text,
                  author_affiliation text,
		  presenter varchar(255),
		  presenter_email varchar(255),
		  presenter_preference varchar(255),
                  keywords text,
                  reviewer_id1 int(11),
                  reviewer_id2 int(11),
                  reviewer_id3 int(11),
		  submit_by int(11),
		  submit_date datetime,
                  customized int(11),
		  PRIMARY KEY (abstract_id)
	  );";

    $updateEmail = "UPDATE " . $table_name . " SET author_email = REPLACE(author_email, ',', ' | ')";
    $updateAffiliation = "UPDATE " . $table_name . " SET author_affiliation = REPLACE(author_affiliation, ',', ' | ')";
    dbDelta($updateEmail);
    dbDelta($updateAffiliation);
    dbDelta($sql);

      // Events Table
   $table_name = $wpdb->prefix."wpabstracts_events";
   $sql = "CREATE TABLE " . $table_name." (
		  event_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		  name varchar(255),
		  description longtext,
		  address longtext,
		  host varchar(255),
                  topics text,
		  start_date date,
		  end_date date,
                  deadline date,
                  customized int(11),
		  PRIMARY KEY  (event_id)
	  );";

      dbDelta($sql);

    $table_name = $wpdb->prefix."wpabstracts_attachments";
    $sql = "CREATE TABLE ".$table_name." (
	  	attachment_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		abstracts_id int(11),
		filecontent longblob,
		filename varchar(255),
		filetype varchar(255),
		filesize varchar(255),
                customized int(11),
		PRIMARY KEY  (attachment_id)
	  );";
      dbDelta($sql);
    $table_name = $wpdb->prefix."wpabstracts_emailtemplates";
    //$wpdb->query("drop table ".$table_name);
    $sql = "CREATE TABLE ".$table_name." (
	  	ID int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
		name varchar(255),
                subject varchar(255),
		message text,
                from_name varchar(255),
                from_email varchar(255),
                receiver varchar(255),
                customized int(11),
		PRIMARY KEY (ID)
	  );";
      dbDelta($sql);

      // settings tab
	add_option("wpabstracts_chars_count", 250);
        add_option("wpabstracts_upload_limit", 3);
	add_option("wpabstracts_max_attach_size", 2048000);
        add_option('wpabstracts_author_instructions', "Enter description here.");
        add_option("wpabstracts_presenter_preference", "Poster,Panel,Roundtable,Projector");
	add_option("wpabstracts_email_admin", 1);
	add_option("wpabstracts_email_author", 1);
	add_option("wpabstracts_frontend_dashboard", 1);
        add_option("wpabstracts_reviewer_submit", 0);
        add_option("wpabstracts_reviewer_edit", 0);
        add_option("wpabstracts_blind_review", 0);
	add_option("wpabstracts_show_adminbar", 0);
	add_option("wpabstracts_permitted_attachments", 'pdf,doc,xls,docx,xlsx,txt,rtf');
	add_option("wpabstracts_change_ownership", 1);
        add_option("wpabstracts_status_notification", 1);
        add_option("wpabstracts_review_notification", 0);
        add_option("wpabstracts_show_reviews", 1);
        add_option("wpabstracts_show_author", 1);
        add_option("wpabstracts_show_presenter", 1);
        add_option("wpabstracts_show_attachments", 1);
        add_option("wpabstracts_show_keywords", 0);
        add_option("wpabstracts_show_conditions", 0);
        add_option("wpabstracts_terms_conditions", "Enter your terms and conditions here.");
        add_option("wpabstracts_sync_status", 0);
        update_option("wpabstracts_version", WPABSTRACTS_VERSION);

        $sql = "SELECT COUNT(*) FROM ". $wpdb->prefix."wpabstracts_emailtemplates";
        if($wpdb->get_var($sql) < 1){
            wpabstracts_installEmailTemplates();
        }else{
            add_option("wpabstracts_submit_templateId", 1);
            add_option("wpabstracts_assignment_templateId", 2);
            add_option("wpabstracts_admin_templateId", 3);
            add_option("wpabstracts_approval_templateId", 4);
            add_option("wpabstracts_rejected_templateId", 5);
            wpabstracts_installEmailTemplates();
        }
}

function wpabstracts_installEmailTemplates(){
    global $wpdb;
    $from_name = get_option('blogname');
    $from_email = get_option('admin_email');

    // submission confirmation template
    if(!get_option('wpabstracts_submit_templateId')){
        $submitConfirmationMsg = 'Hi {DISPLAY_NAME},
                You have successfully submitted your abstract.
                Abstracts Title: {ABSTRACT_TITLE}
                Abstracts ID: {ABSTRACT_ID}
                Event: {EVENT_NAME}
                To make changes to your submission or view the status visit {SITE_URL} and sign in to your dashboard.
                Regards,
                WP Abstracts Team
                {SITE_NAME}
                {SITE_URL}';

        $submitConfirmationTemplate = array(
                    'name' => "Abstracts Submission Acknowledgement",
                    'subject' => "Abstract Submitted Successfully",
                    'message'=> $submitConfirmationMsg,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Authors"
                );
        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $submitConfirmationTemplate);
        add_option("wpabstracts_submit_templateId", $wpdb->insert_id);
    }

    // reviewer assignment template
    if(!get_option('wpabstracts_assignment_templateId')){
        $reviewerAssignmentMsg = 'Hello {DISPLAY_NAME},
                    You have been assigned a new abstract for review.
                    To review this or other abstracts please sign in at: {SITE_URL}
                    Regards,
                    WP Abstracts Team
                    {SITE_NAME}
                    {SITE_URL}';

        $reviewerAssignmentTemplate = array(
                    'name' => "Reviewer Assignment",
                    'subject' => "New Abstract Assigned",
                    'message'=> $reviewerAssignmentMsg,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Reviewers"
                );

        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $reviewerAssignmentTemplate);
        add_option("wpabstracts_assignment_templateId", $wpdb->insert_id);
    }

    // admin submission notification template
    if(!get_option('wpabstracts_admin_templateId')){
        $adminNotications = 'Hello {DISPLAY_NAME},
                        You have a new abstract for {SITE_NAME}
                        Abstract Title: {ABSTRACT_TITLE}
                        Abstract ID: {ABSTRACT_ID}
                        Regards,
                        WP Abstracts Team
                        {SITE_NAME}
                        {SITE_URL}';
        $adminEmailTemplate = array(
                    'name' => "Abstract Submission Notification",
                    'subject' => "New Abstract Submitted",
                    'message'=> $adminNotications,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Administrators"
                );
        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $adminEmailTemplate);
        add_option("wpabstracts_admin_templateId", $wpdb->insert_id);
    }

    // author acceptance notification template
    if(!get_option('wpabstracts_approval_templateId')){
        $authorApprovalMsg = 'Hello {DISPLAY_NAME},
                        We are happy to announce that your abstract entitled {ABSTRACT_TITLE} was approved.
                        Regards,
                        WP Abstracts Team
                        {SITE_NAME}
                        {SITE_URL}';
        $authorApprovalTemplate = array(
                    'name' => "Abstract Approval Notification",
                    'subject' => "Abstract Approved",
                    'message'=> $authorApprovalMsg,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Auhtors"
                );
        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $authorApprovalTemplate);
        add_option("wpabstracts_approval_templateId", $wpdb->insert_id);
    }

    // author rejection notification template
    if(!get_option('wpabstracts_rejected_templateId')){
        $authorRejectedMsg = 'Hello {DISPLAY_NAME},
                        We are sorry to inform you that your abstract entitled {ABSTRACT_TITLE} was rejected.
                        Regards,
                        WP Abstracts Team
                        {SITE_NAME}
                        {SITE_URL}';
        $authorRejectedTemplate = array(
                    'name' => "Abstract Rejection Notification",
                    'subject' => "Abstract Rejected",
                    'message'=> $authorRejectedMsg,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Authors"
                );
        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $authorRejectedTemplate);
        add_option("wpabstracts_rejected_templateId", $wpdb->insert_id);
    }

     // author rejection notification template
    if(!get_option('wpabstracts_reviewed_templateId')){
        $authorReviewsMsg = 'Hello {DISPLAY_NAME},
                        We are happy to inform you that a reviewer submitted comments for your submission.
                        To review these comments and please login in to your dashboard at {SITE_URL}
                        Regards,
                        WP Abstracts Team
                        {SITE_NAME}
                        {SITE_URL}';
        $authorReviewedTemplate = array(
                    'name' => "Reviewer Comments Submitted",
                    'subject' => "Reviewer Comments Submitted",
                    'message'=> $authorReviewsMsg,
                    'from_name' => $from_name,
                    'from_email' => $from_email,
                    'receiver' => "Authors"
                );
        $wpdb->insert($wpdb->prefix.'wpabstracts_emailtemplates', $authorReviewedTemplate);
        add_option("wpabstracts_reviewed_templateId", $wpdb->insert_id);
    }
}

function wpabstracts_version_check(){
    if(!(get_option( "wpabstracts_db_upgraded") == "Y")){
         wpabstracts_upgrade_db();
    }
    if(!(get_option( "wpabstracts_version") == WPABSTRACTS_VERSION)){
         wpabstracts_install();
    }
}

function wpabstracts_upgrade_db(){
    global $wpdb;
    // upgrade abstracts table
    $oldtable_name = $wpdb->prefix."wpabstracts_submissions";
    $newtable_name = $wpdb->prefix."wpabstracts_abstracts";
    $sql = "ALTER TABLE ".$oldtable_name." RENAME TO $newtable_name";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." ADD status varchar(25);";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." CHANGE id abstract_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT;";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." CHANGE event event int(11);";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." ADD topic varchar(55);";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." CHANGE rid reviewer_id1 int(11)";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." ADD reviewer_id2 int(11);";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." ADD reviewer_id3 int(11);";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." CHANGE submit_date submit_date datetime;";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$newtable_name." ADD author_affiliation varchar(255);";
    $wpdb->query($sql);
    // upgrade reviews table
    $reviews_table = $wpdb->prefix."wpabstracts_reviews";
    $sql = "SHOW INDEXES FROM " .$reviews_table;
    $indexes = $wpdb->get_results($sql);
    foreach($indexes as $index){
        if($index->Column_name == "abstract_id" ){
            $sql = "DROP INDEX " . $index->Key_name . " ON " . $reviews_table;
            $wpdb->query($sql);
        }
    }
    // upgrade event table
    $events_table = $wpdb->prefix."wpabstracts_events";
    $sql = "ALTER TABLE ".$events_table." ADD topics text;";
    $wpdb->query($sql);
    $sql = "ALTER TABLE ".$events_table." CHANGE id event_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT;";
    $wpdb->query($sql);
    // upgrade attachments table
    $attachments_table = $wpdb->prefix."wpabstracts_attachments";
    $sql = "ALTER TABLE ".$attachments_table." CHANGE id attachment_id int(11) UNSIGNED NOT NULL AUTO_INCREMENT;";
    $wpdb->query($sql);
    // store option to show DB updated and current version
    update_option('wpabstracts_db_upgraded', 'Y');
}

function wpabstracts_loadJS() {
    wp_enqueue_script('wpabstracts-scripts', plugins_url('js/wpabstracts.js', __FILE__), array( 'jquery' ));
    wp_enqueue_script('wpabstracts-bootstrap-js', plugins_url('js/bootstrap.min.js', __FILE__), array( 'jquery' ));
    wp_enqueue_script('wpabstracts-jquery-ui-js', plugins_url('js/jquery-ui.min.js', __FILE__), array( 'jquery' ));
    wp_enqueue_script('wpabstracts-alertify-js', plugins_url('js/alertify.js', __FILE__), array( 'jquery' ));
    wpabstracts_localize();
}

function wpabstracts_loadCSS(){
    wp_enqueue_style('wpabstracts-style', plugins_url('css/wpabstracts.css', __FILE__));
    wp_enqueue_style('wpabstracts-alertify-css', plugins_url('css/alertify.css', __FILE__));
    wp_enqueue_style('wpabstracts-jquery-ui-css', plugins_url('css/jquery-ui.css', __FILE__));
    wp_enqueue_style('wpabstracts-jquery-ui-ie-css', plugins_url('css/jquery-ui-ie.css', __FILE__));
}

function wpabstracts_localize(){
    wp_localize_script('wpabstracts-scripts', 'front_ajax',
            array('ajaxurl' => admin_url('admin-ajax.php'),
                'name_event' => __('Please enter a name for your event', 'wpabstracts'),
                'authorName' => __('Name', 'wpabstracts'),
                'authorEmail' => __('Email', 'wpabstracts'),
                'confirmdelete' => __('Do you really want to delete this abstract and all its attachments?', 'wpabstracts'),
                'confirmdeleteEvent' => __('Do you really want to delete this event?', 'wpabstracts'),
                'confirmdeleteReview' => __('Do you really want to delete this review?', 'wpabstracts'),
                'confirmdeleteAttachment' => __('Do you really want to delete this attachment?', 'wpabstracts'),
                'confirmdeleteUser' => __('Are you sure you want to delete this user?', 'wpabstracts'),
                'hostedby' => __('hosted by', 'wpabstracts'),
                'assign_reviewer' => apply_filters('wpabstracts_title_filter', __("Assign Reviewer", 'wpabstracts'), 'assign_reviewer'),
                'review_alert' => __('Review Alert', 'wpabstracts'),
                'fillin' => __('Please fill in all required fields.', 'wpabstracts'),
                'topic' => __('Topic', 'wpabstracts'),
                'affiliation' => apply_filters('wpabstracts_title_filter', __("Affiliation", 'wpabstracts'), 'affiliation'),
            )
    );
}

function wpabstracts_getreviewers_ajax(){
    require_once(apply_filters('wpabstracts_page_include', WPABSTRACTS_PLUGIN_DIR . 'wpabstracts_abstracts.php'));
    wpabstracts_getReviewers();
}

function wpabstracts_checkreviews_ajax(){
    require_once(apply_filters('wpabstracts_page_include', WPABSTRACTS_PLUGIN_DIR . 'wpabstracts_reviews.php'));
    wpabstracts_checkReviews();
}

function wpabstracts_loadtopics_ajax(){
    require_once(apply_filters('wpabstracts_page_include', WPABSTRACTS_PLUGIN_DIR . 'wpabstracts_events.php'));
    wpabstracts_loadTopics();
}

function wpabstracts_editor_admin_init() {
    wp_enqueue_script('post');
    wp_enqueue_script('editor');
    wp_enqueue_script('media-upload');
}

function wpabstracts_set_html_content_type() {
    return 'text/html';
}

function wpabstracts_editor_init( $initArray ){
    $initArray['setup'] = <<<JS
[function(ed) {
    ed.onKeyUp.add(function(ed, e){
        wpabstracts_updateWordCount();
    });
}][0]
JS;
    return $initArray;
}

/****************** AUTO-UPDATER *******************/
$api_url = 'http://updates.wpabstracts.com/';

$plugin_slug = basename(dirname(__FILE__));

function wpabstracts_updater($checked_data) {
    global $api_url, $plugin_slug, $wp_version;

    if (empty($checked_data->checked)){
        return $checked_data;
    }

    $args = array(
            'slug' => $plugin_slug,
            'version' => $checked_data->checked[$plugin_slug .'/'. $plugin_slug .'.php'],
    );
    $request_string = array(
                    'body' => array(
                            'action' => 'basic_check',
                            'request' => serialize($args),
                            'api-key' => md5(get_bloginfo('url'))
                    ),
                    'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo('url')
            );

    // Start checking for an update
    $raw_response = wp_remote_post($api_url, $request_string);

    if (!is_wp_error($raw_response) && ($raw_response['response']['code'] == 200)){
        $response = unserialize($raw_response['body']);
    }

    if (is_object($response) && !empty($response)){
        $checked_data->response[$plugin_slug .'/'.$plugin_slug.'.php'] = $response;
    }

    return $checked_data;
}

function wpabstracts_api_call($def, $action, $args) {
    global $plugin_slug, $api_url, $wp_version;

    if (isset($args->slug) && ($args->slug != $plugin_slug)){
        return false;
    }
    // Get the current version
    $plugin_info = get_site_transient('update_plugins');
    $current_version = $plugin_info->checked[$plugin_slug .'/'.$plugin_slug.'.php'];
    $args->version = $current_version;

    $request_string = array(
                    'body' => array(
                            'action' => $action,
                            'request' => serialize($args),
                            'api-key' => md5(get_bloginfo('url'))
                    ),
                    'user-agent' => 'WordPress/' . $wp_version . '; ' . get_bloginfo('url')
            );

    $request = wp_remote_post($api_url, $request_string);
    $res = unserialize($request['body']);

    return $res;
}


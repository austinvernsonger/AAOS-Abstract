<?php
defined('ABSPATH') or die("ERROR: You do not have permission to access this page");

global $wpdb;
$abstracts = $wpdb->get_results("SELECT SQL_CALC_FOUND_ROWS * FROM ".$wpdb->prefix."wpabstracts_abstracts ORDER BY abstract_id DESC LIMIT 0,5");
$abs_count = $wpdb->get_var("SELECT FOUND_ROWS()");
$reviews = $wpdb->get_results("SELECT SQL_CALC_FOUND_ROWS * FROM ".$wpdb->prefix."wpabstracts_reviews ORDER BY review_id DESC LIMIT 0,5");
$approved_abs = $wpdb->get_var("SELECT COUNT(*) FROM ".$wpdb->prefix."wpabstracts_abstracts WHERE status = 'Approved'");
$rejected_abs = $wpdb->get_var("SELECT COUNT(*) FROM ".$wpdb->prefix."wpabstracts_abstracts WHERE status = 'Rejected'");
$pending_abs = $wpdb->get_var("SELECT COUNT(*) FROM ".$wpdb->prefix."wpabstracts_abstracts WHERE status = 'Pending'");
$attachments = $wpdb->get_results("SELECT SQL_CALC_FOUND_ROWS * FROM ".$wpdb->prefix."wpabstracts_attachments ORDER BY attachment_id DESC LIMIT 0,5");
$attachments_count = $wpdb->get_var("SELECT FOUND_ROWS()");
?>

<br>
<div class="wpabstracts container-fluid wpabstracts-admin-container">
    <div class="wpabstracts row">
    <div class="wpabstracts col-xs-12 col-md-9">
        <div class="wpabstracts panel panel-primary">
            <div class="wpabstracts panel-heading">
                <h4><?php echo apply_filters('wpabstracts_title_filter', __('Recent Abstracts','wpabstracts'), 'recent_abstracts');?></h4>
            </div>
            <div class="wpabstracts panel-body">
                <table class="wpabstracts table table-striped">
                    <thead>
                        <tr>
                        <th><?php _e('Abstract Title', 'wpabstracts'); ?></th>
                        <?php if(get_option('wpabstracts_show_author')){ ?>
                        <th><?php _e('Author', 'wpabstracts'); ?></th>
                        <th><?php _e('Author Email', 'wpabstracts'); ?></th>
                        <?php } ?>
                        <th><?php _e('Submit by', 'wpabstracts'); ?></th>
                        <th><?php _e('Date', 'wpabstracts'); ?></th>
                        </tr>
                    </thead>
                        <tbody>
                    <?php
                    foreach($abstracts as $abstract) {
                    ?>
                            <tr>
                                <td><a href="?page=wpabstracts&tab=abstracts&task=edit&id=<?php echo $abstract->abstract_id ?>"><?php echo $abstract->title ?></a></td>
                                <?php if(get_option('wpabstracts_show_author')){ ?>
                                <td><?php echo $abstract->author?></td>
                                <td><a href="mailto:<?php echo $abstract->author_email?>"><?php echo $abstract->author_email?></a></td>
                                <?php } ?>
                                <td><?php
                                    $user_info = get_userdata($abstract->submit_by);
                                    if($user_info){
                                        echo $user_info->display_name;
                                    }else{
                                        _e('--Deleted--', 'wpabstracts');
                                    }
                                    ?>
                                </td>

                                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($abstract->submit_date)); ?></td>

                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>

            </div>

        </div>

    </div>


    <div class="wpabstracts col-xs-12 col-md-3">
        <div class="wpabstracts panel panel-primary">
            <div class="wpabstracts panel-heading">
                <h4><?php echo apply_filters('wpabstracts_title_filter', __('Analytics','wpabstracts'), 'analytics');?></h4>
            </div>
            <div class="wpabstracts panel-body">
                <table class="wpabstracts table table-striped">
                    <tr><td><?php _e('Total Abstracts', 'wpabstracts'); ?></td><td><?php echo esc_attr($abs_count); ?></td></tr>
                    <tr><td><?php _e('Approved', 'wpabstracts'); ?></td><td><?php echo $approved_abs; ?></td></tr>
                    <tr><td><?php _e('Pending', 'wpabstracts'); ?></td><td><?php echo $pending_abs; ?></td></tr>
                    <tr><td><?php _e('Rejected', 'wpabstracts'); ?></td><td><?php echo $rejected_abs; ?></td></tr>
                    <tr><td><?php _e('Attachments', 'wpabstracts'); ?></td><td><?php echo esc_attr($attachments_count); ?></td></tr>
                </table>
            </div>
        </div>
    </div>

    <div class="wpabstracts col-xs-12 col-md-9">
        <div class="wpabstracts panel panel-primary">
            <div class="wpabstracts panel-heading">
                <h4><?php echo apply_filters('wpabstracts_title_filter', __('Recent Reviews','wpabstracts'), 'recent_reviews');?></h4>
            </div>
            <div class="wpabstracts panel-body">
                <table class="wpabstracts table table-striped">
                        <thead>
                        <tr>
                        <th><?php _e('Recent Reviews', 'wpabstracts'); ?></th>
                        <th><?php _e('Comments', 'wpabstracts'); ?></th>
                        <th><?php _e('Reviewer', 'wpabstracts'); ?></th>
                        <th><?php _e('Suggested Status', 'wpabstracts'); ?></th>
                        <th><?php _e('Date', 'wpabstracts'); ?></th>
                        </tr>
                        </thead>
                        <tbody>
                    <?php foreach($reviews as $review) {
                        $currentAbstract = $wpdb->get_row("SELECT title FROM ".$wpdb->prefix."wpabstracts_abstracts WHERE abstract_id = $review->abstract_id");
                        ?>
                            <tr>
                                <td><a href="?page=wpabstracts&tab=reviews&task=edit&id=<?php echo$review->review_id?>"><?php echo $currentAbstract->title; ?></a></td>
                                <td><?php echo $review->comments; ?></td>
                            <?php
                            $user_info = get_userdata($review->user_id);
                            if($user_info){
                                $reviewer = $user_info->display_name;
                            }
                            else{
                                $reviewer = __("Not Assigned",'wpabstracts');
                            }
                        ?>
                                <td><?php echo $reviewer; ?></td>
                                 <td><?php echo $review->status; ?></td>
                                <td><?php echo date_i18n(get_option('date_format') . ' ' . get_option('time_format'), strtotime($review->review_date)); ?></td>
                            </tr>
                        <?php } ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>

    <div class="wpabstracts col-xs-12 col-md-3">
        <div class="wpabstracts panel panel-primary">
            <div class="wpabstracts panel-heading">
                <h4><?php echo apply_filters('wpabstracts_title_filter', __('Help us Improve','wpabstracts'), 'help_improve');?></h4>
            </div>
            <div class="wpabstracts panel-body">
                <p><a href="http://www.wpabstracts.com/wishlist" target="_blank"><?php _e('Suggest', 'wpabstracts'); ?></a> <?php _e('features', 'wpabstracts'); ?>.</p>
                <p><a href="http://wordpress.org/plugins/wp-abstracts-manuscripts-manager/" target="_blank"><?php _e('Rate', 'wpabstracts'); ?></a> <?php _e('the plugin 5 stars on WordPress.org.', 'wpabstracts');?></p>
                <p><a href="http://www.facebook.com/wpabstracts" target="_blank"><?php _e('Like us', 'wpabstracts'); ?></a> on Facebook. </p>
            </div>
        </div>
    </div>

    <div class="wpabstracts col-xs-12 col-md-9">
        <div class="wpabstracts panel panel-primary">
            <div class="wpabstracts panel-heading">
                <h4><?php echo apply_filters('wpabstracts_title_filter', __('Recent Attachments','wpabstracts'), 'recent_attachments');?></h4>
            </div>
            <div class="wpabstracts panel-body">
                <table class="wpabstracts table table-striped">
                    <thead>
                        <tr>
                        <th><?php _e('File Name', 'wpabstracts'); ?></th>
                        <th><?php _e('File Type', 'wpabstracts'); ?></th>
                        <th><?php _e('File Size', 'wpabstracts'); ?></th>
                        </thead>
                        <tbody>
                        <?php foreach($attachments as $attachment) { ?>
                            <tr>
                                <td><?php echo $attachment->filename ?></td>
                                <td><?php echo $attachment->filetype?></td>
                                <td><?php echo number_format(($attachment->filesize/1048576), 2);?>MB</td>
                            </tr>
                        <?php } ?>
                        </tbody>
                </table>
            </div>
        </div>

    </div>
    </div>
</div>